create schema if not exists secrets;

create table secrets.users
(
    name  text constraint users_pk primary key,
    token text
);

create table secrets.secrets
(
    id       uuid default gen_random_uuid()
        constraint secrets_pk
            primary key,
    owner    text
        constraint secrets_users_name_fk
            references secrets.users,
    secret text
);

INSERT INTO secrets.users (name, token) VALUES ('admin', 'hehe_no_password_here');
INSERT INTO secrets.secrets (owner, secret) VALUES ('admin', 'and_no_flag')